module.exports = {
  User: require('./User'),
};
